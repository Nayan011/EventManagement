package com.ea.expresshire.services.email;

public interface EmailService {

	public void sendEmail(String to, String subject, String text);

}
