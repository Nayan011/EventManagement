package com.ea.expresshire.model;

public enum UserType {
    ROLE_APPLICANT, ROLE_RECRUITER, ROLE_ADMIN
}
