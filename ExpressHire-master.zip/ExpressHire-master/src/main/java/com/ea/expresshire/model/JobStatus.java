package com.ea.expresshire.model;

/**
 * Created by Raw on 8/15/2017.
 */
public enum JobStatus {
    OPEN, ONGOING, COMPLETED

}
