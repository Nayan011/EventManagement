package com.ea.expresshire.services.ReviewRating;

import com.ea.expresshire.model.ReviewRating;

/**
 * Created by kcp on 8/12/17.
 */

public interface ReviewRatingService {
    public void addReviewRating(ReviewRating reviewRating);
}
