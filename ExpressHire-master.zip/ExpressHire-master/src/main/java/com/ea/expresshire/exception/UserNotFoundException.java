package com.ea.expresshire.exception;


public class UserNotFoundException extends ParentException {

    public UserNotFoundException(String message) {
        super(message);
    }
}
