package com.ea.expresshire.exception;



public class UserNotAuthenticatedException extends ParentException {

    public UserNotAuthenticatedException(String message) {
        super(message);
    }
}
