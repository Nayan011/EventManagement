package com.ea.expresshire.exception;

public class ParentException extends Exception {

    public ParentException(String message) {
        super(message);
    }
}
